import pymongo
import certifi

con_srt = "mongodb+srv://cluster0.elf6z37.mongodb.net/myFirstDatabase"
client = pymongo.MongoClient(con_srt, tlsCAFile=certifi.where())

db = client.get_database('Organika')

me = {
    'first': 'Saul',
    'last': "Nuñez",
    'age': 23,
    'hobbies': ['music', 'movies', 'sports'],
    'address': {
        'street': 'Main St',
        'number': 345,
        'city': 'New York',
    }

}
